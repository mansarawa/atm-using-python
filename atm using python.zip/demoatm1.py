price=0
withdrow=0

while(1):
    print("press 1 for deposite")
    print("press 2 for transfer")
    print("press 3 for check balance")
    number=int(input())
    
    if(number==1):
        user_name=input("enter user name")
        password=int(input("enter password"))
        if(user_name.lower()=="admin" and password==7773):                 
            amount=int(input("enter amout for deposite"))
            price=price+amount
        else:
            print("invalid username ya password")
    elif(number==2):
        user_name=input("enter user name")
        password=int(input("enter password"))
        if(user_name.lower()=="admin" and password==7773):
            if(price!=0):
                withdrow=int(input("enter amount for Withdrow"))
                print("your current balance is",price-withdrow)
            else:
                print("sorry please deposite amount for WIthdrow")
        else:
            print("invalid username ya password")
    elif(number==3):
        user_name=input("enter user name")
        password=int(input("enter password"))
        if(user_name.lower()=="admin" and password==7773):
            print(price-withdrow)
        else:
            print("invalid password and user name")
    else:
                   print("invalid_input")
                
    
